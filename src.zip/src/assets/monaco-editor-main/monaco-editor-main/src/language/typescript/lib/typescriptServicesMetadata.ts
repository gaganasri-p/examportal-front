//
// **NOTE**: Do not edit directly! This file is generated using `npm run import-typescript`
//

export const typescriptVersion = "5.0.2";
