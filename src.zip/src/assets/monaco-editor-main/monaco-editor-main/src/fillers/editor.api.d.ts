declare module 'vs/editor/editor.api' {
	const x: any;
	export = x;
}
